# #%%
# import numpy as np
# import plotly.graph_objects as go
# import multiprocessing
# import pickle
# import os
# import gc
# from functools import partial
# from plotly.colors import sample_colorscale
# from multiprocessing.dummy import Pool as ThreadPool


# def Plot_Phase_Disgram(m1, m2, planes):
#     pair = tuple(sorted((m1, m2))) 
#     labels = [p[-1] for p in planes]
#     planes = [p[0:-1] for p in planes]

#     eta_C = -9.2230488
#     eta_N = -8.3162684
    
#     x_grid_min, x_grid_max = eta_C-5, eta_C+5
#     y_grid_min, y_grid_max = eta_N-5, eta_N+5
#     resolution = 400

#     x = np.linspace(x_grid_min, x_grid_max, resolution)
#     y = np.linspace(y_grid_min, y_grid_max, resolution)
#     x, y = np.meshgrid(x, y)

#     zs = [(-a * x - b * y - d) / c for a, b, c, d in planes]
#     z_stack = np.stack(zs)

#     min_indices = np.argmin(z_stack, axis=0)
#     valid_indices = np.unique(min_indices)
#     zmin=np.min(valid_indices)
#     zmax=np.max(valid_indices)
#     hover_text = np.array(labels, dtype=object)[min_indices]
#     hovertemplate = "x: %{x:.2f}<br>y: %{y:.2f}<br>Phase: %{text}<extra></extra>"

#     fig = go.Figure(data=go.Heatmap(z=min_indices,x=x[0],y=y[:,0],text=hover_text,hovertemplate=hovertemplate,hoverinfo='text',
#                                     colorscale='Viridis',showscale=False, zmin=zmin, zmax=zmax))

#     fig.add_trace(go.Scatter(x=[eta_C, eta_C], y=[eta_N-5, eta_N+5], mode='lines', line=dict(color='gray', width=3),
#                              name = "Chemical Potential of C from Graphene", opacity=0.5))
#     fig.add_trace(go.Scatter(x=[eta_C-5, eta_C+5], y=[eta_N, eta_N], mode='lines', line=dict(color='gray', width=3),
#                              name = "Chemical Potential of N from Graphene", opacity=0.5))
    
#     ################################################
#     valid_indices = np.unique(min_indices)
#     order_list = []
#     for idx in valid_indices:
#         y_points = y[min_indices == idx]
#         representative_y = y_points.max() if y_points.size > 0 else -np.inf
#         order_list.append((idx, representative_y))

#     order_list.sort(key=lambda x: x[1], reverse=True)
#     ordered_valid_indices = [entry[0] for entry in order_list]
    
#     for idx in ordered_valid_indices:
#         fraction = idx / zmax
#         color = sample_colorscale('Viridis', fraction)[0]
#         fig.add_trace(go.Scatter(x=[None],y=[None],mode='markers',marker=dict(size=10, color=color),
#                                  legendgroup=labels[idx],showlegend=True,name=labels[idx]))
#     print(f"Legend for {pair[0]}-{pair[1]}:", [labels[idx] for idx in ordered_valid_indices])
#     ################################################
    
    
#     fig.update_layout(
#         title=dict(text=f"Phase Diagram of {pair[0]} and {pair[1]}",x=0.35,xanchor='center',font=dict(family="Times New Roman",size=40, color="black")),
#         xaxis=dict(range=[x_grid_min, x_grid_max],title="$\\Huge \\eta_C$",titlefont=dict(family="Times New Roman", size=10, color="black"),
#                     tickfont=dict(family="Times New Roman", size=24, color="black")),width=1150,
#         yaxis=dict(range=[y_grid_min, y_grid_max],title="$\\Huge \\eta_N$",titlefont=dict(family="Times New Roman", size=10, color="black"),
#                     tickfont=dict(family="Times New Roman", size=24, color="black")),height=800,
#         showlegend=True, legend=dict(orientation="v", y=1, xanchor="left", x=1.02,traceorder="normal",
#                                         font=dict(family="Times New Roman", size=20, color="black")),
#         margin=dict(l=80, r=200, t=80, b=80))


#     html_str = fig.to_html(include_plotlyjs="cdn", include_mathjax="cdn", full_html=False)

#     wrapped_html = f"""
#     <html>
#       <head>
#         <style>
#           /* This container centers the content horizontally, then shifts it right by 200px */
#           .plot-container {{
#             width: 100%;
#             display: flex;
#             justify-content: center;
#             margin-left: 140px; /* Adjust this value to move the plot right */
#           }}
#         </style>
#       </head>
#       <body>
#         <div class="plot-container">
#           {html_str}
#         </div>
#       </body>
#     </html>
#     """

#     #with open(f"../localenergy_page/PhaseDiagrams/{pair[0]}_{pair[1]}.html", "w") as f:
#     with open(f"./PhaseDiagrams/{pair[0]}_{pair[1]}.html", "w") as f:
#         f.write(wrapped_html)

#     del fig
#     gc.collect()

#     return [pair]


# finished = []
# def assemble(parameter):
#     if parameter[0] != None:
#         finished.append(parameter[0])
#         print(len(finished))
#     else:
#         print("RWONG!")
    


# def abortable_worker(func, *args, **kwargs):
#     timeout = kwargs.get('timeout', None)
#     p = ThreadPool(1)
#     res = p.apply_async(func, args = args)
#     try:
#         out = res.get(timeout)
#     except multiprocessing.TimeoutError:
#         p.terminate()
#         print("Aborting due to timeout.")
#         print("Failed to analyze the structure %s within limit time."%args[0])
#         out = [None]
#     finally:
#         p.close()
#         p.join()
#     return out



# with open("./Phases_Dict.pkl", "rb") as f:
#     Phases_Dict = pickle.load(f)

# tasks = [(m1, m2, tuple(sorted((m1, m2)))) for (m1, m2) in Phases_Dict.keys()]


# if __name__ == "__main__":
#     # """
#     for (m1, m2, pair) in tasks:
#         planes = Phases_Dict[pair]
#         Plot_Phase_Disgram(m1, m2, planes,)
#         break
#     # """

#     # pool = multiprocessing.Pool(12)
#     # for (m1, m2, pair) in tasks:
#     #     planes = Phases_Dict[pair]
#     #     abortable_func = partial(abortable_worker, Plot_Phase_Disgram, timeout=600)
#     #     pool.apply_async(abortable_func, args = (m1, m2, planes,), callback = assemble)
#     # pool.close()
#     # pool.join()

    
#     print("All phase diagrams have been generated.")
















#%%
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成带插图的相图 HTML：
 1. 读取 Phases_Dict.pkl，生成 Plotly 相图（大图 HTML 片段 + legend 列表）
 2. 根据 legend 列表生成对应小图（PNG），只对 legend 第二段中未出现的位点画红圈
 3. 将大图和所有小图（带名称）拼到一个 HTML 文件中
"""

import os
import gc
import pickle
import numpy as np
import plotly.graph_objects as go
from plotly.colors import sample_colorscale
from PIL import Image, ImageDraw, ImageFont   # ← 这里多了 ImageFont
import colorsys

TEXT_SIZE = 28   # ⬅︎ ① 这里改数字即可调大小；20‑30 比较合适
# ------------------------
# 1) QV 模板图路径
# ------------------------
template_paths = {
    'QV1': './QVtemplate/1.png',
    'QV2': './QVtemplate/2.png',
    'QV3': './QVtemplate/3.png',
    'QV4': './QVtemplate/4.png',
    'QV5': './QVtemplate/5.png',
    'QV6': './QVtemplate/6.png',
}

# ------------------------
# 2) 每个模板上的 0–5 六个位点，以及 M1、M2（固定两个金属位置）
#    坐标在模板图中用像素值表示
# ------------------------
site_coords = {
    'QV1': {
        0: (138, 121), 1: (209, 162), 2: (174, 222),
        3: ( 68, 121), 4: ( 34, 182), 5: (104, 222),
        'M1': ( 86, 172), 'M2': (156, 172),
    },
    'QV2': {
        0: ( 68, 242), 1: ( 68, 162), 2: (139, 162),
        3: (209, 162), 4: (209, 242), 5: (139, 242),
        'M1': (174, 202), 'M2': (103, 202),
    },
    'QV3': {
        0: (208, 161), 1: (208, 242), 2: (138, 241),
        3: (137, 120), 4: ( 68, 161), 5: (103, 221),
        'M1': (172, 201), 'M2': (120, 170),
    },
    'QV4': {
        0: (208, 120), 1: (105, 100), 2: (174,  61),
        3: (140, 162), 4: (208, 162), 5: (208, 242),
        'M1': (174, 202), 'M2': (156, 111),
    },
    'QV5': {
        0: (207, 119), 1: (207,  38), 2: (136, 119), 3: (137,  38),
        4: (138, 159), 5: (207, 159), 6: (207, 241), 7: (137, 241),
        'M1': (174, 202), 'M2': (174,  80),
    },
    'QV6': {
        0: ( 68, 120), 1: (102,  60), 2: (172, 100),
        3: (140, 162), 4: (208, 162), 5: (208, 242), 6: (139, 241),
        'M1': (174, 202), 'M2': (120, 110),
    },
}

# ------------------------
# 3) 用户提供的金属元素列表
# ------------------------
metal_list = [
    "Sc", "Ti", "V", "Cr", "Mn", "Fe", "Co", "Ni", "Cu", "Zn",
    "Y", "Zr", "Nb", "Mo", "Tc", "Ru", "Rh", "Pd", "Ag", "Cd",
    "Ce", "Hf", "Ta", "W",  "Re", "Os", "Ir", "Pt", "Au",
    "Al", "Ga", "Ge", "In", "Sn", "Sb", "Tl", "Pb", "Bi"
]

# ------------------------
# 4) 自动为每个金属生成颜色（HSV 色相均匀分布）
# ------------------------
metal_colors = {}
n_m = len(metal_list)
for i, m in enumerate(metal_list):
    h = i / n_m
    r, g, b = colorsys.hsv_to_rgb(h, 0.7, 0.9)
    metal_colors[m] = '#{:02x}{:02x}{:02x}'.format(int(r*255), int(g*255), int(b*255))


def Plot_Phase_Disgram(m1, m2, planes):
    """
    使用 Plotly 生成相图，返回：
      html_str: 图的 <div> 片段
      legend_list: 按顺序的 legend 字符串列表
    """
    pair = tuple(sorted((m1, m2)))
    labels = [p[-1] for p in planes]
    planes_coef = [p[:-1] for p in planes]

    eta_C, eta_N = -9.2230488, -8.3162684
    x_min, x_max = eta_C - 5, eta_C + 5
    y_min, y_max = eta_N - 5, eta_N + 5

    res = 100
    x = np.linspace(x_min, x_max, res)
    y = np.linspace(y_min, y_max, res)
    X, Y = np.meshgrid(x, y)

    zs = [(-a*X - b*Y - d)/c for (a, b, c, d) in planes_coef]
    Z  = np.stack(zs, axis=0)

    min_idx   = np.argmin(Z, axis=0)
    valid_idx = np.unique(min_idx)
    zmin, zmax = valid_idx.min(), valid_idx.max()

    hover_text    = np.array(labels, dtype=object)[min_idx]
    hovertemplate = "x: %{x:.2f}<br>y: %{y:.2f}<br>Phase: %{text}<extra></extra>"

    fig = go.Figure(data=go.Heatmap(
        z=min_idx, x=x, y=y, text=hover_text,
        hovertemplate=hovertemplate, showscale=False,
        colorscale='Viridis', zmin=zmin, zmax=zmax
    ))

    # 参考线
    fig.add_trace(go.Scatter(
        x=[eta_C, eta_C], y=[y_min, y_max],
        mode='lines', line=dict(color='gray', width=3),
        name="μ_C from Graphene", opacity=0.5
    ))
    fig.add_trace(go.Scatter(
        x=[x_min, x_max], y=[eta_N, eta_N],
        mode='lines', line=dict(color='gray', width=3),
        name="μ_N from Graphene", opacity=0.5
    ))

    # legend 排序
    order = []
    for idx in valid_idx:
        y_pts = Y[min_idx == idx]
        order.append((idx, y_pts.max() if y_pts.size else -np.inf))
    order.sort(key=lambda x: x[1], reverse=True)
    ordered_idx = [idx for idx, _ in order]

    for idx in ordered_idx:
        frac   = idx / zmax if zmax != 0 else 0
        clr_pt = sample_colorscale('Viridis', frac)[0]
        fig.add_trace(go.Scatter(
            x=[None], y=[None],
            mode='markers',
            marker=dict(size=10, color=clr_pt),
            legendgroup=labels[idx],
            showlegend=True,
            name=labels[idx]
        ))

    fig.update_layout(
        title=dict(
            text=f"Phase Diagram of {pair[0]}-{pair[1]}",
            x=0.35, xanchor='center',
            font=dict(family="Times New Roman", size=40)
        ),
        xaxis=dict(
            range=[x_min, x_max], title="$\\eta_C$",
            titlefont=dict(family="Times New Roman", size=24),
            tickfont=dict(family="Times New Roman", size=20)
        ),
        yaxis=dict(
            range=[y_min, y_max], title="$\\eta_N$",
            titlefont=dict(family="Times New Roman", size=24),
            tickfont=dict(family="Times New Roman", size=20)
        ),
        width=1150, height=800,
        showlegend=True,
        legend=dict(
            orientation="v", y=1, xanchor="left", x=1.02,
            font=dict(family="Times New Roman", size=20)
        ),
        margin=dict(l=80, r=200, t=80, b=80)
    )

    html_str = fig.to_html(
        include_plotlyjs="cdn",
        include_mathjax="cdn",
        full_html=False
    )

    # 清理
    fig.data = []
    fig.layout = {}
    del fig
    gc.collect()

    legend_list = [labels[idx] for idx in ordered_idx]
    return html_str, legend_list


def make_inset(legend_str, out_dir='./insets'):
    """
    生成对应小图并返回文件路径：
      • legend 第二段中未出现的位点：蓝色实心圆
      • 金属位点：金属颜色实心圆，圆心写上金属名
    """
    qv, sites_str, m1, m2 = legend_str.split('_')
    img  = Image.open(template_paths[qv]).convert('RGBA')
    draw = ImageDraw.Draw(img)
    try:                                     # ② 替换为下面这行
        font = ImageFont.truetype("DejaVuSans-Bold.ttf", TEXT_SIZE)
    except OSError:                          # 若找不到字体则退回默认位图字体
        print('not found')
        font = ImageFont.load_default()

    # 所有整数位点
    all_sites = [k for k in site_coords[qv].keys() if isinstance(k, int)]
    present   = [int(ch) for ch in sites_str] if sites_str else []

    # 未出现的位点 → 蓝色实心圆
    for idx in all_sites:
        if idx not in present:
            x, y = site_coords[qv][idx]
            r = 12
            draw.ellipse([x-r, y-r, x+r, y+r], fill='blue')  # 实心填充

    # 金属位点 → 金属颜色实心圆 + 元素文字
    for pos_label, metal in (('M1', m1), ('M2', m2)):
        x, y = site_coords[qv][pos_label]
        r    = 16
        clr  = metal_colors.get(metal, '#000000')
        draw.ellipse([x-r, y-r, x+r, y+r], fill=clr)        # 实心填充
        # ---------- 兼容 Pillow 旧 / 新版本 ----------
        if hasattr(draw, "textbbox"):                 # Pillow ≥10
            bbox = draw.textbbox((0, 0), metal, font=font)
            w, h = bbox[2] - bbox[0], bbox[3] - bbox[1]
        else:                                         # Pillow <10
            w, h = draw.textsize(metal, font=font)
        # --------------------------------------------
        draw.text((x - w/2, y - h/2), metal, fill='black', font=font)

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir, f"{legend_str}.png")
    img.save(path)
    return path


import os

def build_full_html(html_main, inset_paths, legend_list, out_html='./Phase_with_insets.html'):
    """
    拼接大图和带名称的小图到一个 HTML
    """
    # 1) 计算 HTML 文件所在目录
    html_dir = os.path.dirname(os.path.abspath(out_html)) or '.'

    # 2) 把每个 inset 的绝对路径，转为相对 html_dir 的相对路径
    rel_paths = [os.path.relpath(p, start=html_dir) for p in inset_paths]

    # 3) 用相对路径生成 <img src="…">
    imgs_html = "\n".join(
        f'''<figure style="display:inline-block; text-align:center; margin:10px;">
  <img src="{rel}" style="height:200px;"><br>
  <figcaption style="font-size:14px;">{label}</figcaption>
</figure>'''
        for rel, label in zip(rel_paths, legend_list)
    )

    full_html = f"""<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Phase Diagram with Insets</title>
    <style>
      .main  {{ text-align:center; }}
      .insets{{ display:flex; flex-wrap:wrap; justify-content:center; margin-top:20px; }}
    </style>
  </head>
  <body>
    <div class="main">
      {html_main}
    </div>
    <div class="insets">
      {imgs_html}
    </div>
  </body>
</html>"""

    # 确保目录存在，再写文件
    os.makedirs(html_dir, exist_ok=True)
    with open(out_html, 'w', encoding='utf-8') as f:
        f.write(full_html)
    print(f"Wrote combined HTML to {out_html}")



if __name__ == '__main__':
    # 读取 Phases_Dict.pkl
    with open('./Phases_Dict.pkl', 'rb') as fp:
        Phases_Dict = pickle.load(fp)

    # 你想生成的前 X 个相图
    NUM = 5   # ← 改成你需要的数量
    # 输出根目录
    OUTPUT_DIR = './phase_outputs'
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # 遍历前 NUM 个 pair
    for pair in list(Phases_Dict.keys())[:NUM]:
        m1, m2 = pair
        planes = Phases_Dict[pair]

        # 1) 生成大图 HTML & legend_list
        html_main, legend_list = Plot_Phase_Disgram(m1, m2, planes)

        # 2) 为本对金属建一个子文件夹，存放 inset 图
        inset_dir = os.path.join(OUTPUT_DIR, f"insets_{m1}_{m2}")
        os.makedirs(inset_dir, exist_ok=True)
        inset_paths = [make_inset(lg, out_dir=inset_dir) for lg in legend_list]

        # 3) 拼接并写出 HTML，文件名用 “M1_M2.html”
        html_file = os.path.join(OUTPUT_DIR, f"{m1}_{m2}.html")
        build_full_html(html_main, inset_paths, legend_list, out_html=html_file)

        print(f"Completed {m1}-{m2} → {html_file}")

    gc.collect()

